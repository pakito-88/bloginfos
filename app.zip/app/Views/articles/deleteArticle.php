<?php $this->layout('layout', ['title' => 'Supprimer']) ?>

<?php $this->start('main_content');?>

supprimé
<?php $this->stop('main_content');?>