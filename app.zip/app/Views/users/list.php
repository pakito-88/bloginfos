<?php $this->layout('layout', ['title' => 'Liste des utilisateurs']) ?>

<?php $this->start('main_content');?>

blabla


<?php $this->stop('main_content');?>